This project is truly based on cucumber frame work
To run this project , please pull it and convert to maven

after that , Open TestRunner class file under src/test/java/ui_tests/RunnerClass/TestRunner.java