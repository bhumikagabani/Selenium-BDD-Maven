package ui_tests.stepDefinitions;

import io.cucumber.java.en.Then;

public class MainPage {
    @Then("user should see user tab")
    public void userShouldSeeUserTab() {

    }
}
