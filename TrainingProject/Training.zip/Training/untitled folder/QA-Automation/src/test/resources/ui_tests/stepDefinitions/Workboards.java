package ui_tests.stepDefinitions;

public class Workboards {
    public Workboards() {
        Then("^click on expandable row$", () -> {
        });
    }
}
